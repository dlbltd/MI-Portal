// ============================================================
// DLB Investigations Ltd — MI Portal Client Data
// Client:  Car Care Plan
// File:    carcareplan.js
// Period:  Jan–Aug 2026
// Updated: 31 Aug 2026
// GENERATED AUTOMATICALLY — DO NOT EDIT MANUALLY
// ============================================================

var DLB_CLIENT_DATA = {

  client_name:                  "Car Care Plan",
  report_period:                "Jan\u2013Aug 2026",
  last_updated:                 "31 Aug 2026",
  is_rtc_client:                false,
  total_cases:                  7,

  avg_days_creation_to_update:         0,
  avg_days_creation_to_update_general: 0,
  avg_days_stmt_to_report:             13,
  avg_days_stmt_to_report_rtc:         0,
  avg_days_stmt_to_report_general:     13,

  sla_ack_pct:                  null,
  sla_contact_pct:              null,
  sla_update_pct:               null,
  sla_report_general_pct:       40,
  sla_report_rtc_pct:           null,
  has_rtc_cases:                false,
  has_general_cases:            true,
  sla_compliance_pct:           40,
  sla_met:                      2,
  sla_not_met:                  3,

  avg_fee_rtc:                  0,
  avg_fee_general:              390.1,
  total_fees_rtc:               0,
  total_fees_general:           2730.7,
  rtc_case_count:               0,
  general_case_count:           7,
  fees_by_type: [
    { type:"Gap Insurance investigation", is_rtc:false, case_count:7, total_fees:2730.7, avg_fee:390.1 }
  ],

  // Line-item-driven revenue (from TrackOps invoice details export)
  total_invoiced_lineitems:     3550.7,
  total_lineitem_count:         10,
  fees_by_item: [
    { item:"Stage 1 Investigation", is_rtc:false, count:3, total:1500, avg:500 },
    { item:"Motor Theft Investigation", is_rtc:false, count:3, total:1400, avg:466.67 },
    { item:"Police Report", is_rtc:false, count:2, total:330.7, avg:165.35 },
    { item:"Stage 2 Investigation", is_rtc:false, count:1, total:200, avg:200 },
    { item:"Cold Calls", is_rtc:false, count:1, total:120, avg:120 }
  ],

  monthly: [
    { month:"Jan", month_num:1, case_count:0, case_count_rtc:0, case_count_general:0, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 },
    { month:"Feb", month_num:2, case_count:1, case_count_rtc:0, case_count_general:1, total_fees:450, ave_fees:450, total_fees_rtc:0, total_fees_general:450, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:4, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:4, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:100, sla_report_general_met:1, sla_report_general_n:1, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:100, sla_met:1, sla_not_met:0 },
    { month:"Mar", month_num:3, case_count:0, case_count_rtc:0, case_count_general:0, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 },
    { month:"Apr", month_num:4, case_count:1, case_count_rtc:0, case_count_general:1, total_fees:643.4, ave_fees:643.4, total_fees_rtc:0, total_fees_general:643.4, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:28, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:28, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:0, sla_report_general_met:0, sla_report_general_n:1, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:1 },
    { month:"May", month_num:5, case_count:3, case_count_rtc:0, case_count_general:3, total_fees:1137.3, ave_fees:379.1, total_fees_rtc:0, total_fees_general:1137.3, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:7.5, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:7.5, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:50, sla_report_general_met:1, sla_report_general_n:2, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:50, sla_met:1, sla_not_met:1 },
    { month:"Jun", month_num:6, case_count:1, case_count_rtc:0, case_count_general:1, total_fees:500, ave_fees:500, total_fees_rtc:0, total_fees_general:500, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:18, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:18, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:0, sla_report_general_met:0, sla_report_general_n:1, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:1 },
    { month:"Jul", month_num:7, case_count:0, case_count_rtc:0, case_count_general:0, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 },
    { month:"Aug", month_num:8, case_count:1, case_count_rtc:0, case_count_general:1, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 },
    { month:"Sep", month_num:9, case_count:0, case_count_rtc:0, case_count_general:0, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 },
    { month:"Oct", month_num:10, case_count:0, case_count_rtc:0, case_count_general:0, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 },
    { month:"Nov", month_num:11, case_count:0, case_count_rtc:0, case_count_general:0, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 },
    { month:"Dec", month_num:12, case_count:0, case_count_rtc:0, case_count_general:0, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 }
  ],

  cases: [
    { ref:"1196208", client_ref:"7382224 - Arya", type:"Gap Insurance investigation", status:"Appointment made", created:"19 Aug 2026", first_updated:"", stmt_date:"", report_sent:"", days_creation_to_update:null, days_stmt_to_report:null, invoice:0, is_rtc_case:false, sla_ack:null, sla_contact:null, sla_update:null, sla_report:null, report_proxy:false, sla_report_target_days:5 },
    { ref:"1171706", client_ref:"6961750 - Sefolli", type:"Gap Insurance investigation", status:"Paid", created:"11 Jun 2026", first_updated:"", stmt_date:"19 Jun 2026", report_sent:"7 Jul 2026", days_creation_to_update:null, days_stmt_to_report:18, invoice:500, is_rtc_case:false, sla_ack:null, sla_contact:null, sla_update:null, sla_report:false, report_proxy:false, sla_report_target_days:5 },
    { ref:"1166205", client_ref:"7298871 - Slane", type:"Gap Insurance investigation", status:"Appointment made", created:"21 May 2026", first_updated:"", stmt_date:"", report_sent:"", days_creation_to_update:null, days_stmt_to_report:null, invoice:0, is_rtc_case:false, sla_ack:null, sla_contact:null, sla_update:null, sla_report:null, report_proxy:false, sla_report_target_days:5 },
    { ref:"1164105", client_ref:"7319591 - Gibbs", type:"Gap Insurance investigation", status:"Paid", created:"18 May 2026", first_updated:"", stmt_date:"19 May 2026", report_sent:"21 May 2026", days_creation_to_update:null, days_stmt_to_report:2, invoice:500, is_rtc_case:false, sla_ack:null, sla_contact:null, sla_update:null, sla_report:true, report_proxy:false, sla_report_target_days:5 },
    { ref:"1161505", client_ref:"7276149 - Kara", type:"Gap Insurance investigation", status:"Paid", created:"6 May 2026", first_updated:"", stmt_date:"15 May 2026", report_sent:"28 May 2026", days_creation_to_update:null, days_stmt_to_report:13, invoice:637.3, is_rtc_case:false, sla_ack:null, sla_contact:null, sla_update:null, sla_report:false, report_proxy:false, sla_report_target_days:5 },
    { ref:"1160104", client_ref:"7298046 - Radford", type:"Gap Insurance investigation", status:"Paid", created:"29 Apr 2026", first_updated:"", stmt_date:"6 May 2026", report_sent:"3 Jun 2026", days_creation_to_update:null, days_stmt_to_report:28, invoice:643.4, is_rtc_case:false, sla_ack:null, sla_contact:null, sla_update:null, sla_report:false, report_proxy:false, sla_report_target_days:5 },
    { ref:"1138802", client_ref:"7226863 - Moseley", type:"Gap Insurance investigation", status:"Paid", created:"17 Feb 2026", first_updated:"", stmt_date:"20 Feb 2026", report_sent:"24 Feb 2026", days_creation_to_update:null, days_stmt_to_report:4, invoice:450, is_rtc_case:false, sla_ack:null, sla_contact:null, sla_update:null, sla_report:true, report_proxy:false, sla_report_target_days:5 }
  ]

};
