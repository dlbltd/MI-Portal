# MI Portal monthly refresh

How to regenerate the client dashboards in `clients/` from TrackOps exports.
Everything below runs locally. Nothing here needs the chat interface.

## Inputs

Two TrackOps CSV exports covering the same date range:

- `cases_<from>_-_<to>_<id>.csv`
- `invoice_details_<from>_-_<to>_<id>.csv`

Drop both into `exports/` (gitignored, see below). The script picks the
newest matching pair automatically.

## Run

```bash
python3 generate.py --exports exports --out clients
```

The period label and last-updated date are derived from the data. Override
them only if you need to:

```bash
python3 generate.py --exports exports --out clients \
  --period "Jan–Sep 2026" --updated "30 Sep 2026"
```

Standard library only. No pip install.

## Before committing

1. Read the script's summary. It reports year corrections, dates it could
   not recover, out-of-order dates, and any client in the data with no
   portal file.
2. Confirm every generated filename already exists in `clients/`. A new
   name means the client has no access code, and the dashboard will 404
   on login until one is added to `CLIENT_REGISTRY` in `scripts/login.js`.
3. Check one dashboard renders before pushing, ideally Zego, since it
   carries the most cases and exercises both the RTC and General panels.
4. Never commit `exports/`. The CSVs hold every client's case and fee data
   in one file, and this repo is public. Add to `.gitignore`:
   ```
   exports/
   ```

## Conventions the script follows

These were taken from the live `clients/zego.js`, not assumed. Changing any
of them changes what clients see, so change them deliberately.

- Report SLA is measured statement to report. Target 2 days for RTC, 5 days
  for everything else, written per case as `sla_report_target_days`.
- Where no statement date exists, report turnaround is measured from the
  first client update instead, and the case is flagged `report_proxy: true`.
- The update SLA (5 days from instruction to first client contact) applies
  to general cases only. RTC cases carry `null`.
- Acknowledgement and contact are not captured in TrackOps. They are
  recorded as met where the case was updated at all, and `null` where it
  was not. Both therefore sit at 100%, which flatters
  `sla_compliance_pct`. Worth fixing at source rather than in this script.
- `sla_compliance_pct` is the aggregate across all four SLA categories.
  `sla_met` / `sla_not_met` count the report SLA only.
- Per-case revenue comes from invoice line items linked on the invoice
  CSV's `Case` column. `total_invoiced_lineitems` counts every invoice row
  for the client including ones against cases opened before the window, so
  the two figures differ by design.
- And-E covers five TrackOps entities: And-E, Kwik-Fit, both Toyota
  entries, and Total Transparent Solutions.

## Data handling

- A date with the wrong year is corrected to the reporting year only where
  the result lands inside the data window. Where it does not, the year was
  not the only thing mistyped, so the field is read as unrecorded and
  reported. The script never guesses at a real date.
- Dates running backwards (a first update before the case was created) are
  keying errors, not turnarounds, so they are excluded from averages and
  listed for fixing in TrackOps.
- Dates legitimately after the period end, where work continued past the
  export, are left alone.

## Known issues at Aug 2026

- 49 cases have a first-update date before the creation date. Mostly First
  Central and MX Oneclaim. Fixing these at source is the single biggest
  improvement available to the reported figures.
- Five date fields on January cases cannot be recovered: 1132601, 1117701
  (three fields), 1131001.
- Transportation has no report date on any of its 44 cases, so nothing is
  measurable and the dashboard reads 0%. That is a recording gap, not a
  service result. Consider holding the file back until it is fixed.
- Zebra has four cases, three with no update date, and the fourth ran 92
  days to first contact. One case is the whole dashboard.
- `itb.js` has no entry in `CLIENT_REGISTRY`, so Insure The Box cannot log
  in. It is not generated.
- Seven registry entries have no cases in the export and keep whatever data
  they already hold: Direct Commercial, Key Claims, MSG, Mulsanne, Rostella,
  XSD, and the demo file. Their period labels will drift out of step.
