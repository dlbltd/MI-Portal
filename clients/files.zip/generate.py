#!/usr/bin/env python3
"""
DLB MI Portal - client data generator.

Reads the two TrackOps exports (cases + invoice_details) and writes one
<client>.js per client in the exact shape the live portal files use.

Conventions taken from the live clients/zego.js rather than assumed:
  - the report SLA is measured statement -> report, target 2 days for
    RTC and 5 days for everything else
  - the update SLA (5 days from instruction to first client contact)
    applies to general cases only, not RTC
  - acknowledgement and contact are not captured in TrackOps, so they
    are recorded as met wherever the case was updated at all, and null
    where it was not
  - sla_compliance_pct is the aggregate across all four SLA categories,
    not the report SLA alone
  - dates render as "5 Jan 2026", with no leading zero
"""
import csv, os, json, datetime as dt
from collections import defaultdict

def cli():
    """Resolve inputs from the command line, or by discovery in --exports.

    Usage:
      python3 generate.py --exports ./exports --out clients --period "Jan-Sep 2026"

    With no arguments it looks for the newest cases_*.csv and
    invoice_details_*.csv in ./exports and writes to ./clients.
    """
    import argparse, glob
    ap = argparse.ArgumentParser(description='Build MI Portal client data files.')
    ap.add_argument('--exports', default='exports', help='folder holding the TrackOps CSV exports')
    ap.add_argument('--cases', help='path to the cases CSV (overrides discovery)')
    ap.add_argument('--invoices', help='path to the invoice_details CSV (overrides discovery)')
    ap.add_argument('--out', default='clients', help='folder to write the .js files into')
    ap.add_argument('--period', help='report period label, e.g. "Jan-Sep 2026"')
    ap.add_argument('--updated', help='last updated label, e.g. "30 Sep 2026"')
    ap.add_argument('--year', type=int, default=2026, help='reporting year')
    a = ap.parse_args()

    def newest(pattern):
        hits = sorted(glob.glob(os.path.join(a.exports, pattern)))
        if not hits:
            raise SystemExit(
                f'No file matching {pattern} in {a.exports!r}. '
                'Put both TrackOps exports there or pass --cases and --invoices.')
        return hits[-1]

    a.cases = a.cases or newest('cases_*.csv')
    a.invoices = a.invoices or newest('invoice_details_*.csv')
    return a


ARGS = cli() if __name__ == '__main__' else None

CASES_CSV = ARGS.cases if ARGS else ''
INV_CSV = ARGS.invoices if ARGS else ''
OUT_DIR = ARGS.out if ARGS else 'clients'

MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]

RTC_REPORT_TARGET = 2
GEN_REPORT_TARGET = 5
UPDATE_TARGET     = 5

DATA_YEAR    = ARGS.year if ARGS else 2026
PERIOD_START = dt.date(DATA_YEAR, 1, 1)
PERIOD_END   = dt.date(DATA_YEAR, 12, 31)   # narrowed to the data in main()
PERIOD       = ARGS.period if (ARGS and ARGS.period) else ''
LAST_UPD     = ARGS.updated if (ARGS and ARGS.updated) else ''

BAD_DATES     = []
YEAR_FIXES    = []
UNRECOVERABLE = []

# TrackOps client name -> (portal filename, display name as used live)
CLIENT_MAP = {
    'Zego':                                       ('zego.js',          'Zego Insurance'),
    'Inshur':                                     ('inshur.js',        'Inshur'),
    'First Central insurance & Technology Group': ('firstcentral.js',  'First Central Insurance'),
    'Trinity Claims Limited':                     ('trinity.js',       'Trinity'),
    'DWF LLP':                                    ('dwf.js',           'DWF Law'),
    'Car Care Plan':                              ('carcareplan.js',   'Car Care Plan'),
    'Transportation Claims Ltd':                  ('transportation.js','Transportation Claims Ltd'),
    'And-E':                                      ('ande.js',          'And-E'),
    'Kwik-Fit Motor Insurance':                   ('ande.js',          'And-E'),
    'Toyota Motor Insurance':                     ('ande.js',          'And-E'),
    'Toyota Insurance Management UK Limited':     ('ande.js',          'And-E'),
    'Total Transparent Solutions Limited':        ('ande.js',          'And-E'),
    'Collingwood Claims':                         ('collingwood.js',   'Collingwood Insurance'),
    'MX One Claim':                               ('mxoneclaim.js',    'MX Oneclaim'),
    'Keoghs LLP':                                 ('keoghs.js',        'Keoghs LLP'),
    'Weightmans':                                 ('weightmans.js',    'Weightmans'),
    'Zebra':                                      ('zebra.js',         'Zebra'),
    'Judge & Priestley Solicitors':               ('jpsolicitors.js',  'J&P Solicitors'),
    'Action 365':                                 ('action365.js',     'Action 365'),
}


def parse_date(s):
    if s is None:
        return None
    s = str(s).strip()
    if not s or s.lower() in ('nan', 'none'):
        return None
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%d %b %Y'):
        try:
            return dt.datetime.strptime(s[:10], fmt).date()
        except ValueError:
            continue
    return None


def parse_case_date(rec, field):
    """Parse a case date, correcting a stray year only where that is safe.

    A year correction is accepted where the result lands inside the
    reporting period. Where it does not, the year was not the only thing
    mistyped and the real date cannot be recovered, so the field is read
    as unrecorded and reported for fixing in TrackOps. Dates legitimately
    after the period end are left alone.
    """
    d = parse_date(rec.get(field))
    if d is None or d.year == DATA_YEAR:
        return d
    case = str(rec.get('Case Number', '')).strip()
    fixed = d.replace(year=DATA_YEAR)
    if PERIOD_START <= fixed <= PERIOD_END:
        YEAR_FIXES.append((case, field, d.isoformat(), fixed.isoformat()))
        return fixed
    UNRECOVERABLE.append((case, field, d.isoformat(), fixed.isoformat()))
    return None


def fmt_date(d):
    return "" if d is None else f"{d.day} {MONTHS[d.month-1]} {d.year}"


def days(a, b, case=None, label=None):
    """Elapsed days, or None where it cannot be measured.

    A negative result means the dates are out of order in TrackOps, which
    is a keying error rather than a turnaround, so it is not averaged in.
    """
    if a is None or b is None:
        return None
    n = (b - a).days
    if n < 0:
        if case is not None:
            BAD_DATES.append((case, label, a.isoformat(), b.isoformat()))
        return None
    return n


def is_rtc_type(t):
    return 'RTC' in str(t).upper()


def pct(met, n):
    return None if not n else round(met / n * 100)


def money(x):
    try:
        return round(float(str(x).replace(',', '').replace('\u00a3', '') or 0), 2)
    except ValueError:
        return 0.0


def r2(x):
    return round(x + 0.0, 2)


def js(v):
    if v is None:
        return "null"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, str):
        return json.dumps(v)
    if isinstance(v, float):
        v = round(v, 2)
        return str(int(v)) if v == int(v) else str(v)
    return str(v)


def row(pairs):
    return "{ " + ", ".join(f"{k}:{js(v)}" for k, v in pairs) + " }"


def mean(v):
    return round(sum(v) / len(v), 1) if v else 0


def build(display_name, filename, case_rows, inv_rows):
    per_case = defaultdict(float)
    for r in inv_rows:
        k = str(r.get('Case', '')).strip()
        if k:
            per_case[k] += money(r.get('Total'))

    rank = {'Sent': 1, 'Partially Paid': 2, 'Paid': 3}
    inv_status = {}
    for r in inv_rows:
        k = str(r.get('Case', '')).strip()
        st = str(r.get('Status', '')).strip()
        if k and rank.get(st, 0) > rank.get(inv_status.get(k, ''), 0):
            inv_status[k] = st

    by_item = defaultdict(lambda: {'count': 0, 'total': 0.0})
    for r in inv_rows:
        it = str(r.get('Item', '')).strip() or 'Unspecified'
        by_item[it]['count'] += 1
        by_item[it]['total'] += money(r.get('Total'))
    fees_by_item = [
        {'item': it, 'is_rtc': 'RTC' in it.upper(), 'count': v['count'],
         'total': r2(v['total']),
         'avg': r2(v['total'] / v['count']) if v['count'] else 0}
        for it, v in sorted(by_item.items(), key=lambda kv: -kv[1]['total'])
    ]

    M = {m: dict(month=m, month_num=i + 1, case_count=0, case_count_rtc=0,
                 case_count_general=0, total_fees=0.0, total_fees_rtc=0.0,
                 total_fees_general=0.0, upd_all=[], upd_gen=[], rpt_all=[],
                 rpt_rtc=[], rpt_gen=[], ack_met=0, ack_n=0, con_met=0, con_n=0,
                 upd_met=0, upd_n=0, gen_met=0, gen_n=0, rtc_met=0, rtc_n=0)
         for i, m in enumerate(MONTHS)}

    cases_out = []
    meta = []  # (is_rtc, d_upd, d_rpt) parallel to cases_out
    by_type = defaultdict(lambda: {'n': 0, 'fees': 0.0, 'is_rtc': False})
    tot = dict(ack_met=0, ack_n=0, con_met=0, con_n=0, upd_met=0, upd_n=0,
               gen_met=0, gen_n=0, rtc_met=0, rtc_n=0)
    rtc_n = gen_n = 0
    fees_rtc = fees_gen = 0.0

    for r in case_rows:
        num = str(r.get('Case Number', '')).strip()
        ctype = str(r.get('Case Type', '')).strip()
        rtc = is_rtc_type(ctype)
        target = RTC_REPORT_TARGET if rtc else GEN_REPORT_TARGET

        created = parse_case_date(r, 'Date Created')
        upd = parse_case_date(r, 'Date client first updated?')
        stmt = parse_case_date(r, 'Date statement obtained')
        rep = parse_case_date(r, 'Date Report sent to client?')

        invoice = r2(per_case.get(num, 0.0))
        d_upd = days(created, upd, num, 'created -> first update')

        proxy = False
        base = stmt
        if base is None and upd is not None:
            base, proxy = upd, True
        d_rpt = days(base, rep, num, 'statement -> report')

        touched = upd is not None
        sla_ack = True if touched else None
        sla_con = True if touched else None
        sla_upd = None if (rtc or d_upd is None) else (d_upd <= UPDATE_TARGET)
        sla_rep = None if d_rpt is None else (d_rpt <= target)

        for key, val in (('ack', sla_ack), ('con', sla_con), ('upd', sla_upd)):
            if val is not None:
                tot[key + '_n'] += 1
                tot[key + '_met'] += 1 if val else 0
        if sla_rep is not None:
            k = 'rtc' if rtc else 'gen'
            tot[k + '_n'] += 1
            tot[k + '_met'] += 1 if sla_rep else 0

        if rtc:
            rtc_n += 1
            fees_rtc += invoice
        else:
            gen_n += 1
            fees_gen += invoice
        t = by_type[ctype]
        t['n'] += 1
        t['fees'] += invoice
        t['is_rtc'] = rtc

        cases_out.append([
            ('ref', num),
            ('client_ref', str(r.get('Reference No.', '') or '').strip()),
            ('type', ctype),
            ('status', inv_status.get(num, str(r.get('Case Status', '') or '').strip())),
            ('created', fmt_date(created)),
            ('first_updated', fmt_date(upd)),
            ('stmt_date', fmt_date(stmt)),
            ('report_sent', fmt_date(rep)),
            ('days_creation_to_update', d_upd),
            ('days_stmt_to_report', d_rpt),
            ('invoice', invoice),
            ('is_rtc_case', rtc),
            ('sla_ack', sla_ack),
            ('sla_contact', sla_con),
            ('sla_update', sla_upd),
            ('sla_report', sla_rep),
            ('report_proxy', proxy),
            ('sla_report_target_days', target),
        ])
        meta.append((rtc, d_upd, d_rpt))

        if created is None:
            continue
        m = M[MONTHS[created.month - 1]]
        m['case_count'] += 1
        m['total_fees'] += invoice
        if rtc:
            m['case_count_rtc'] += 1
            m['total_fees_rtc'] += invoice
        else:
            m['case_count_general'] += 1
            m['total_fees_general'] += invoice
        if d_upd is not None:
            m['upd_all'].append(d_upd)
            if not rtc:
                m['upd_gen'].append(d_upd)
        if d_rpt is not None:
            m['rpt_all'].append(d_rpt)
            (m['rpt_rtc'] if rtc else m['rpt_gen']).append(d_rpt)
        for key, val in (('ack', sla_ack), ('con', sla_con), ('upd', sla_upd)):
            if val is not None:
                m[key + '_n'] += 1
                m[key + '_met'] += 1 if val else 0
        if sla_rep is not None:
            k = 'rtc' if rtc else 'gen'
            m[k + '_n'] += 1
            m[k + '_met'] += 1 if sla_rep else 0

    monthly = []
    for mn in MONTHS:
        m = M[mn]
        allmet = m['ack_met'] + m['con_met'] + m['upd_met'] + m['gen_met'] + m['rtc_met']
        alln = m['ack_n'] + m['con_n'] + m['upd_n'] + m['gen_n'] + m['rtc_n']
        n = m['case_count']
        monthly.append([
            ('month', m['month']), ('month_num', m['month_num']),
            ('case_count', n), ('case_count_rtc', m['case_count_rtc']),
            ('case_count_general', m['case_count_general']),
            ('total_fees', r2(m['total_fees'])),
            ('ave_fees', r2(m['total_fees'] / n) if n else 0),
            ('total_fees_rtc', r2(m['total_fees_rtc'])),
            ('total_fees_general', r2(m['total_fees_general'])),
            ('ave_days_creation_to_update', mean(m['upd_all'])),
            ('ave_days_creation_to_update_general', mean(m['upd_gen'])),
            ('ave_days_stmt_to_report', mean(m['rpt_all'])),
            ('ave_days_stmt_to_report_rtc', mean(m['rpt_rtc'])),
            ('ave_days_stmt_to_report_general', mean(m['rpt_gen'])),
            ('sla_ack_pct', pct(m['ack_met'], m['ack_n'])),
            ('sla_ack_met', m['ack_met']), ('sla_ack_n', m['ack_n']),
            ('sla_contact_pct', pct(m['con_met'], m['con_n'])),
            ('sla_contact_met', m['con_met']), ('sla_contact_n', m['con_n']),
            ('sla_update_pct', pct(m['upd_met'], m['upd_n'])),
            ('sla_update_met', m['upd_met']), ('sla_update_n', m['upd_n']),
            ('sla_report_general_pct', pct(m['gen_met'], m['gen_n'])),
            ('sla_report_general_met', m['gen_met']), ('sla_report_general_n', m['gen_n']),
            ('sla_report_rtc_pct', pct(m['rtc_met'], m['rtc_n'])),
            ('sla_report_rtc_met', m['rtc_met']), ('sla_report_rtc_n', m['rtc_n']),
            ('sla_compliance_pct', pct(allmet, alln) or 0),
            ('sla_met', m['gen_met'] + m['rtc_met']),
            ('sla_not_met', (m['gen_n'] - m['gen_met']) + (m['rtc_n'] - m['rtc_met'])),
        ])

    upd_all = [u for _, u, _ in meta if u is not None]
    upd_gen = [u for rtc_, u, _ in meta if u is not None and not rtc_]
    rpt_all = [p for _, _, p in meta if p is not None]
    rpt_rtc = [p for rtc_, _, p in meta if p is not None and rtc_]
    rpt_gen = [p for rtc_, _, p in meta if p is not None and not rtc_]

    allmet = sum(tot[k + '_met'] for k in ('ack', 'con', 'upd', 'gen', 'rtc'))
    alln = sum(tot[k + '_n'] for k in ('ack', 'con', 'upd', 'gen', 'rtc'))

    fees_by_type = [
        {'type': t, 'is_rtc': v['is_rtc'], 'case_count': v['n'],
         'total_fees': r2(v['fees']),
         'avg_fee': r2(v['fees'] / v['n']) if v['n'] else 0}
        for t, v in sorted(by_type.items(), key=lambda kv: -kv[1]['fees'])
    ]

    d = {
        'client_name': display_name,
        'report_period': PERIOD,
        'last_updated': LAST_UPD,
        'is_rtc_client': rtc_n > 0,
        'total_cases': len(cases_out),
        'avg_days_creation_to_update': mean(upd_all),
        'avg_days_creation_to_update_general': mean(upd_gen),
        'avg_days_stmt_to_report': mean(rpt_all),
        'avg_days_stmt_to_report_rtc': mean(rpt_rtc),
        'avg_days_stmt_to_report_general': mean(rpt_gen),
        'sla_ack_pct': pct(tot['ack_met'], tot['ack_n']),
        'sla_contact_pct': pct(tot['con_met'], tot['con_n']),
        'sla_update_pct': pct(tot['upd_met'], tot['upd_n']),
        'sla_report_general_pct': pct(tot['gen_met'], tot['gen_n']),
        'sla_report_rtc_pct': pct(tot['rtc_met'], tot['rtc_n']),
        'has_rtc_cases': rtc_n > 0,
        'has_general_cases': gen_n > 0,
        'sla_compliance_pct': pct(allmet, alln) or 0,
        'sla_met': tot['gen_met'] + tot['rtc_met'],
        'sla_not_met': (tot['gen_n'] - tot['gen_met']) + (tot['rtc_n'] - tot['rtc_met']),
        'avg_fee_rtc': r2(fees_rtc / rtc_n) if rtc_n else 0,
        'avg_fee_general': r2(fees_gen / gen_n) if gen_n else 0,
        'total_fees_rtc': r2(fees_rtc),
        'total_fees_general': r2(fees_gen),
        'rtc_case_count': rtc_n,
        'general_case_count': gen_n,
        'fees_by_type': fees_by_type,
        'total_invoiced_lineitems': r2(sum(money(r.get('Total')) for r in inv_rows)),
        'total_lineitem_count': len(inv_rows),
        'fees_by_item': fees_by_item,
        'monthly': monthly,
        'cases': cases_out,
    }
    return d, render(d, filename)


def render(d, filename):
    def block(rows_):
        return ',\n'.join('    ' + row(r) for r in rows_)

    def dicts(items, keys):
        return ',\n'.join('    ' + row([(k, i[k]) for k in keys]) for i in items)

    types = dicts(d['fees_by_type'], ['type', 'is_rtc', 'case_count', 'total_fees', 'avg_fee'])
    items = dicts(d['fees_by_item'], ['item', 'is_rtc', 'count', 'total', 'avg'])

    return f'''// ============================================================
// DLB Investigations Ltd \u2014 MI Portal Client Data
// Client:  {d['client_name']}
// File:    {filename}
// Period:  {d['report_period']}
// Updated: {d['last_updated']}
// GENERATED AUTOMATICALLY \u2014 DO NOT EDIT MANUALLY
// ============================================================

var DLB_CLIENT_DATA = {{

  client_name:                  {js(d['client_name'])},
  report_period:                {js(d['report_period'])},
  last_updated:                 {js(d['last_updated'])},
  is_rtc_client:                {js(d['is_rtc_client'])},
  total_cases:                  {d['total_cases']},

  avg_days_creation_to_update:         {js(d['avg_days_creation_to_update'])},
  avg_days_creation_to_update_general: {js(d['avg_days_creation_to_update_general'])},
  avg_days_stmt_to_report:             {js(d['avg_days_stmt_to_report'])},
  avg_days_stmt_to_report_rtc:         {js(d['avg_days_stmt_to_report_rtc'])},
  avg_days_stmt_to_report_general:     {js(d['avg_days_stmt_to_report_general'])},

  sla_ack_pct:                  {js(d['sla_ack_pct'])},
  sla_contact_pct:              {js(d['sla_contact_pct'])},
  sla_update_pct:               {js(d['sla_update_pct'])},
  sla_report_general_pct:       {js(d['sla_report_general_pct'])},
  sla_report_rtc_pct:           {js(d['sla_report_rtc_pct'])},
  has_rtc_cases:                {js(d['has_rtc_cases'])},
  has_general_cases:            {js(d['has_general_cases'])},
  sla_compliance_pct:           {d['sla_compliance_pct']},
  sla_met:                      {d['sla_met']},
  sla_not_met:                  {d['sla_not_met']},

  avg_fee_rtc:                  {js(d['avg_fee_rtc'])},
  avg_fee_general:              {js(d['avg_fee_general'])},
  total_fees_rtc:               {js(d['total_fees_rtc'])},
  total_fees_general:           {js(d['total_fees_general'])},
  rtc_case_count:               {d['rtc_case_count']},
  general_case_count:           {d['general_case_count']},
  fees_by_type: [
{types if types else "    // No cases in this period"}
  ],

  // Line-item-driven revenue (from TrackOps invoice details export)
  total_invoiced_lineitems:     {js(d['total_invoiced_lineitems'])},
  total_lineitem_count:         {d['total_lineitem_count']},
  fees_by_item: [
{items if items else "    // No invoice line items in this period"}
  ],

  monthly: [
{block(d['monthly'])}
  ],

  cases: [
{block(d['cases']) if d['cases'] else "    // No cases in this period"}
  ]

}};
'''


def main():
    global PERIOD, LAST_UPD, PERIOD_END
    with open(CASES_CSV, encoding='utf-8-sig') as f:
        cases = list(csv.DictReader(f))
    with open(INV_CSV, encoding='utf-8-sig') as f:
        inv = list(csv.DictReader(f))
    os.makedirs(OUT_DIR, exist_ok=True)

    # Derive the period from the data unless it was given on the command line,
    # so the label can never drift from what the dashboards actually show.
    created = sorted(d for d in (parse_date(r.get('Date Created')) for r in cases) if d)
    if created:
        first, last = created[0], created[-1]
        PERIOD_END = last   # a corrected date must land inside the data window
        if not PERIOD:
            PERIOD = (f'{MONTHS[first.month-1]}\u2013{MONTHS[last.month-1]} {last.year}'
                      if first.month != last.month else f'{MONTHS[last.month-1]} {last.year}')
        if not LAST_UPD:
            LAST_UPD = fmt_date(last)
    print(f'Reading {os.path.basename(CASES_CSV)} and {os.path.basename(INV_CSV)}')
    print(f'Period: {PERIOD}   Last updated: {LAST_UPD}   Writing to: {OUT_DIR}/\n')

    cby, iby, names, skipped = defaultdict(list), defaultdict(list), {}, defaultdict(int)
    for r in cases:
        cl = str(r.get('Client', '')).strip()
        if cl in CLIENT_MAP:
            fn, disp = CLIENT_MAP[cl]
            cby[fn].append(r)
            names[fn] = disp
        else:
            skipped[cl] += 1
    for r in inv:
        cl = str(r.get('Client', '')).strip()
        if cl in CLIENT_MAP:
            fn, disp = CLIENT_MAP[cl]
            iby[fn].append(r)
            names.setdefault(fn, disp)

    def f_(v):
        return '-' if v is None else str(v)

    print(f"{'Client':26s} {'File':19s} {'Cases':>5s} {'RTC':>4s} {'PerCase':>9s} "
          f"{'RTC%':>5s} {'Gen%':>5s} {'Upd%':>5s} {'Overall':>8s}")
    print('-' * 98)
    for fn in sorted(set(cby) | set(iby)):
        d, out = build(names[fn], fn, cby.get(fn, []), iby.get(fn, []))
        with open(os.path.join(OUT_DIR, fn), 'w') as f:
            f.write(out)
        percase = d['total_fees_rtc'] + d['total_fees_general']
        print(f"{names[fn]:26s} {fn:19s} {d['total_cases']:5d} {d['rtc_case_count']:4d} "
              f"{percase:9,.0f} {f_(d['sla_report_rtc_pct']):>5s} "
              f"{f_(d['sla_report_general_pct']):>5s} {f_(d['sla_update_pct']):>5s} "
              f"{d['sla_compliance_pct']:7d}%")

    if YEAR_FIXES:
        print(f'\nStray years corrected to {DATA_YEAR} ({len(YEAR_FIXES)}):')
        for c, fl, a, b in YEAR_FIXES:
            print(f'  case {c}: {fl}  {a} -> {b}')
    if UNRECOVERABLE:
        print(f'\nWrong year and wrong date, read as unrecorded ({len(UNRECOVERABLE)}):')
        for c, fl, a, b in UNRECOVERABLE:
            print(f'  case {c}: {fl}  {a}')
    if BAD_DATES:
        print(f'\nOut-of-order dates, excluded from averages ({len(BAD_DATES)}):')
        for c, fl, a, b in BAD_DATES[:8]:
            print(f'  case {c}: {fl}  {a} -> {b}')
        if len(BAD_DATES) > 8:
            print(f'  ... and {len(BAD_DATES)-8} more')
    if skipped:
        print('\nNot mapped to a portal file:')
        for cl, n in sorted(skipped.items(), key=lambda kv: -kv[1]):
            print(f'  {cl}  ({n} cases)')


if __name__ == '__main__':
    main()
