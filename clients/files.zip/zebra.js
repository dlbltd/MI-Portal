// ============================================================
// DLB Investigations Ltd — MI Portal Client Data
// Client:  Zebra
// File:    zebra.js
// Period:  Jan–Aug 2026
// Updated: 31 Aug 2026
// GENERATED AUTOMATICALLY — DO NOT EDIT MANUALLY
// ============================================================

var DLB_CLIENT_DATA = {

  client_name:                  "Zebra",
  report_period:                "Jan\u2013Aug 2026",
  last_updated:                 "31 Aug 2026",
  is_rtc_client:                false,
  total_cases:                  4,

  avg_days_creation_to_update:         92,
  avg_days_creation_to_update_general: 92,
  avg_days_stmt_to_report:             6,
  avg_days_stmt_to_report_rtc:         0,
  avg_days_stmt_to_report_general:     6,

  sla_ack_pct:                  100,
  sla_contact_pct:              100,
  sla_update_pct:               0,
  sla_report_general_pct:       0,
  sla_report_rtc_pct:           null,
  has_rtc_cases:                false,
  has_general_cases:            true,
  sla_compliance_pct:           50,
  sla_met:                      0,
  sla_not_met:                  1,

  avg_fee_rtc:                  0,
  avg_fee_general:              322.65,
  total_fees_rtc:               0,
  total_fees_general:           1290.6,
  rtc_case_count:               0,
  general_case_count:           4,
  fees_by_type: [
    { type:"Motor Fraud", is_rtc:false, case_count:3, total_fees:1170.6, avg_fee:390.2 },
    { type:"Intelligence Report", is_rtc:false, case_count:1, total_fees:120, avg_fee:120 }
  ],

  // Line-item-driven revenue (from TrackOps invoice details export)
  total_invoiced_lineitems:     1290.6,
  total_lineitem_count:         8,
  fees_by_item: [
    { item:"Stage 1 Investigation", is_rtc:false, count:1, total:550, avg:550 },
    { item:"Stage 2 Investigation", is_rtc:false, count:1, total:200, avg:200 },
    { item:"Miscellanoeus", is_rtc:false, count:1, total:128, avg:128 },
    { item:"Intelligence Report Only", is_rtc:false, count:1, total:120, avg:120 },
    { item:"Investigator Defence Statement", is_rtc:false, count:1, total:120, avg:120 },
    { item:"Police Report", is_rtc:false, count:1, total:80.4, avg:80.4 },
    { item:"Cold Calls", is_rtc:false, count:1, total:60, avg:60 },
    { item:"Police reference request", is_rtc:false, count:1, total:32.2, avg:32.2 }
  ],

  monthly: [
    { month:"Jan", month_num:1, case_count:1, case_count_rtc:0, case_count_general:1, total_fees:120, ave_fees:120, total_fees_rtc:0, total_fees_general:120, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 },
    { month:"Feb", month_num:2, case_count:1, case_count_rtc:0, case_count_general:1, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 },
    { month:"Mar", month_num:3, case_count:2, case_count_rtc:0, case_count_general:2, total_fees:1170.6, ave_fees:585.3, total_fees_rtc:0, total_fees_general:1170.6, ave_days_creation_to_update:92, ave_days_creation_to_update_general:92, ave_days_stmt_to_report:6, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:6, sla_ack_pct:100, sla_ack_met:1, sla_ack_n:1, sla_contact_pct:100, sla_contact_met:1, sla_contact_n:1, sla_update_pct:0, sla_update_met:0, sla_update_n:1, sla_report_general_pct:0, sla_report_general_met:0, sla_report_general_n:1, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:50, sla_met:0, sla_not_met:1 },
    { month:"Apr", month_num:4, case_count:0, case_count_rtc:0, case_count_general:0, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 },
    { month:"May", month_num:5, case_count:0, case_count_rtc:0, case_count_general:0, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 },
    { month:"Jun", month_num:6, case_count:0, case_count_rtc:0, case_count_general:0, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 },
    { month:"Jul", month_num:7, case_count:0, case_count_rtc:0, case_count_general:0, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 },
    { month:"Aug", month_num:8, case_count:0, case_count_rtc:0, case_count_general:0, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 },
    { month:"Sep", month_num:9, case_count:0, case_count_rtc:0, case_count_general:0, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 },
    { month:"Oct", month_num:10, case_count:0, case_count_rtc:0, case_count_general:0, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 },
    { month:"Nov", month_num:11, case_count:0, case_count_rtc:0, case_count_general:0, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 },
    { month:"Dec", month_num:12, case_count:0, case_count_rtc:0, case_count_general:0, total_fees:0, ave_fees:0, total_fees_rtc:0, total_fees_general:0, ave_days_creation_to_update:0, ave_days_creation_to_update_general:0, ave_days_stmt_to_report:0, ave_days_stmt_to_report_rtc:0, ave_days_stmt_to_report_general:0, sla_ack_pct:null, sla_ack_met:0, sla_ack_n:0, sla_contact_pct:null, sla_contact_met:0, sla_contact_n:0, sla_update_pct:null, sla_update_met:0, sla_update_n:0, sla_report_general_pct:null, sla_report_general_met:0, sla_report_general_n:0, sla_report_rtc_pct:null, sla_report_rtc_met:0, sla_report_rtc_n:0, sla_compliance_pct:0, sla_met:0, sla_not_met:0 }
  ],

  cases: [
    { ref:"1143703", client_ref:"CB23099MUL", type:"Motor Fraud", status:"Paid", created:"10 Mar 2026", first_updated:"10 Jun 2026", stmt_date:"12 Jun 2026", report_sent:"18 Jun 2026", days_creation_to_update:92, days_stmt_to_report:6, invoice:1050.6, is_rtc_case:false, sla_ack:true, sla_contact:true, sla_update:false, sla_report:false, report_proxy:false, sla_report_target_days:5 },
    { ref:"1141803", client_ref:"SN23037MUL", type:"Motor Fraud", status:"Sent", created:"2 Mar 2026", first_updated:"", stmt_date:"", report_sent:"", days_creation_to_update:null, days_stmt_to_report:null, invoice:120, is_rtc_case:false, sla_ack:null, sla_contact:null, sla_update:null, sla_report:null, report_proxy:false, sla_report_target_days:5 },
    { ref:"1140702", client_ref:"CBK2500955ZUR", type:"Motor Fraud", status:"Invoice Paid", created:"23 Feb 2026", first_updated:"", stmt_date:"", report_sent:"", days_creation_to_update:null, days_stmt_to_report:null, invoice:0, is_rtc_case:false, sla_ack:null, sla_contact:null, sla_update:null, sla_report:null, report_proxy:false, sla_report_target_days:5 },
    { ref:"1133601", client_ref:"CB2500881ZUR", type:"Intelligence Report", status:"Paid", created:"26 Jan 2026", first_updated:"", stmt_date:"", report_sent:"", days_creation_to_update:null, days_stmt_to_report:null, invoice:120, is_rtc_case:false, sla_ack:null, sla_contact:null, sla_update:null, sla_report:null, report_proxy:false, sla_report_target_days:5 }
  ]

};
